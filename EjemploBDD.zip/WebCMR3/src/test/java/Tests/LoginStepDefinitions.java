package Tests;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	@Given("^que el usuario este en el sitio$")
	public void que_el_usuario_este_en_el_sitio() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^el usuario clickea iniciar sesion$")
	public void el_usuario_clickea_iniciar_sesion() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^el usuario ingresar al sitio de login$")
	public void el_usuario_ingresar_al_sitio_de_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^el usuario ingresa usuario y password validos$")
	public void el_usuario_ingresa_usuario_y_password_validos() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^el usuario se logea correctamente$")
	public void el_usuario_se_logea_correctamente() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
