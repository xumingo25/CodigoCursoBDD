package Tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	// Instanciar el WebDriver
	WebDriver driver;

	// Ruta del webDriver
	static String directorioActual = System.getProperty("user.dir");
	static String rutaDriver = "\\Drivers\\chromedriver.exe";
	static String rutaCompleta = directorioActual + rutaDriver;

	@Given("^que el usuario este en el sitio$")
	public void que_el_usuario_este_en_el_sitio() throws Throwable {
		// Asignaci�n de ruta del webdriver al property webdriver.chrome.driver
		System.setProperty("webdriver.chrome.driver", rutaCompleta);

		// Instaciar el webdriver como un Chromedriver
		this.driver = new ChromeDriver();

		// MAnejo del tiempo de espera implicito en la carga de elementos web
		this.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		// Manejo del tama�o de la ventana del navegador
		this.driver.manage().window().maximize();

		// Levantar el browser
		this.driver.get("https://www.falabella.com/");

	}

	@When("^el usuario clickea iniciar sesion$")
	public void el_usuario_clickea_iniciar_sesion() throws Throwable {
		WebElement btnInicio = driver.findElement(
				By.xpath("//div[@class='fb-masthead-login__name re-design-cl__name login-redesing_logout-box']"));

		btnInicio.click();
	}

	@Then("^el usuario ingresar al sitio de login$")
	public void el_usuario_ingresar_al_sitio_de_login() throws Throwable {

		try {
			boolean existeIniciaSesion = driver.findElement(By.xpath("//div[@class='Login__mainContent__ZxAuN']"))
					.isDisplayed();
			if (existeIniciaSesion) {
				Assert.assertTrue("Se visualiza pagina la login al site", existeIniciaSesion);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	@When("^el usuario ingresa usuario y password validos$")
	public void el_usuario_ingresa_usuario_y_password_validos(DataTable datos) throws Throwable {
		// Lista para trabajar con los datos del feature
		List<String> datosPrueba = datos.asList(String.class);
		int cantElementos = datosPrueba.size();
		String username = null;
		String password = null;
		if (cantElementos == 2) {
			username = datosPrueba.get(0).toString();
			password = datosPrueba.get(1).toString();
		} else {
			Assert.assertTrue("No hay consistencia de datos de prueba para aplicar un login", false);
		}

		WebElement mail = driver.findElement(By.id("emailAddress"));
		WebElement contrasena = driver.findElement(By.xpath("//input[@name='password']"));
		WebElement btnLogin = driver.findElement(By.xpath("//p[contains(text(),'Iniciar sesi�n')]"));

		// Ingresar user y password
		mail.sendKeys(username);
		contrasena.sendKeys(password);

		if (btnLogin.isEnabled()) {
			// Click en btn iniciar sesi�n
			btnLogin.click();
		}else{
			Assert.assertTrue("Boton de login no se habilita", false);
		}
	}

	@Then("^el usuario se logea correctamente$")
	public void el_usuario_se_logea_correctamente() throws Throwable {
		try{
			WebElement mensajeBienvenida = driver.findElement(By.xpath("//div[contains(text(),'Bienvenid')]"));
			if(mensajeBienvenida.isDisplayed()){
				Assert.assertTrue("Login exitoso. se visualiza mensaje de bienvenida del sitio", true);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
