package Tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	
	//Creaci�n de variable webdriver
	WebDriver driver;
	
	//Configurar la ruta del WebDriver
	static String directorioActual = System.getProperty("user.dir");
	static String rutaWebDriver = "\\Drivers\\chromedriver.exe";
	static String rutaCompleta = directorioActual + rutaWebDriver;
	

	@Given("^que el usuario este en la pagina de falabella$")
	public void que_el_usuario_este_en_la_pagina_de_falabella() throws Throwable {
		
		//Asignar webdriver al property de sistema
		System.setProperty("webdriver.chrome.driver", rutaCompleta);
		
		//Instanciar el driver
		this.driver = new ChromeDriver();
		
		//Agregar tiempo implicito al driver
		this.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//Maximizar pantalla
		this.driver.manage().window().maximize();
		
		//Abrir el sitio de falabella
		this.driver.get("https://www.falabella.com/");
	}

	@When("^el usuario clickea iniciar sesion$")
	public void el_usuario_clickea_iniciar_sesion() throws Throwable {
		WebElement linkInicio = driver.findElement
				(By.xpath("//div[@class='fb-masthead-login__name re-design-cl__name login-redesing_logout-box']"));
		
		linkInicio.click();
	}

	@Then("^el usuario ingresa al login page del sitio$")
	public void el_usuario_ingresa_al_login_page_del_sitio() throws Throwable {
		try{
			
			boolean existeSesionPage = driver.findElement
					(By.xpath("//div[@class='Login__mainContent__ZxAuN']")).isEnabled();
			
			
			if(existeSesionPage){
				Assert.assertTrue("Se despliega correctamente pop up de inicio de sesion",existeSesionPage);
			}
		}catch(Exception ex){
			throw ex;
		}
	}

	@When("^el usuario ingresa usuario y password correctos$")
	public void el_usuario_ingresa_usuario_y_password_correctos(DataTable testData) throws Throwable {
		//Se instancia un objeto de tipo lista de String
		List<String> datosPrueba = testData.asList(String.class);
		
		//Se cuenta la cantidad de elementos de la lista
		int cantidadElementos = datosPrueba.size();
		
		String nombreUsuario = null;
		String password = null;
		
		if(cantidadElementos == 2){
			nombreUsuario = datosPrueba.get(0).toString();
			password = datosPrueba.get(1).toString();
		}else{
			Assert.assertTrue("No hay data disponible", false);
		}
		
		// Obtener elementos web mail, password y boton iniciar sesi�n
		WebElement mail = driver.findElement(By.id("emailAddress"));
		WebElement contrasena = driver.findElement(By.xpath("//input[@name='password']"));
		WebElement btnInicioSesion = driver.findElement(By.xpath("//p[contains(text(),'Iniciar sesi�n')]"));
		
		//Ingresar informaci�n
		mail.sendKeys(nombreUsuario);
		contrasena.sendKeys(password);
		
		//Validar que el boton este habilitado
		if(btnInicioSesion.isEnabled()){
			btnInicioSesion.click();
		}else{
			Assert.assertTrue("NO esta habilidato boton para iniciar sesi�n", false);
		}
		
	}

	@Then("^el usuario se logea correctamente$")
	public void el_usuario_se_logea_correctamente() throws Throwable {
		
		try{
			WebElement mensajeBienvenida = 
					driver.findElement
					(By.xpath("//div[contains(text(),'Bienvenid')]"));
			if(mensajeBienvenida.isDisplayed()){
				Assert.assertTrue("Se encuentra mensaje de bienvenida", true);
			}
		} catch (Exception e){
			
		}
		
	}
}
